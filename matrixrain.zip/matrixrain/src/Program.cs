﻿using System;
using System.Drawing;
using System.Threading;

using Bytewizer.MatrixRain.Properties;

using GHIElectronics.TinyCLR.Pins;
using GHIElectronics.TinyCLR.Devices.Gpio;
using GHIElectronics.TinyCLR.Devices.Display;

namespace Bytewizer.MatrixRain
{
    class Program
    {
        // fields
        static readonly Font digitalFont
            = Resources.GetFont(Resources.FontResources.RobotoFont);

        static readonly Random rand = new Random();

        // properties
        static char AsciiCharacter
        {
            get
            {
                int t = rand.Next(10);
                if (t <= 2)
                    // returns a number
                    return (char)('0' + rand.Next(10));
                else if (t <= 4)
                    // small letter
                    return (char)('a' + rand.Next(27));
                else if (t <= 6)
                    // capital letter
                    return (char)('A' + rand.Next(27));
                else
                    // any ascii character
                    return (char)(rand.Next(255));
            }
        }

        static void Main()
        {
            // setup the display
            var backlight = GpioController.GetDefault().OpenPin(SC20260.GpioPin.PA15);
            backlight.SetDriveMode(GpioPinDriveMode.Output);
            backlight.Write(GpioPinValue.High);

            var controller = DisplayController.GetDefault();
            controller.SetConfiguration(new ParallelDisplayControllerSettings
            {
                Width = 480,
                Height = 272,
                DataFormat = DisplayDataFormat.Rgb565,
                Orientation = DisplayOrientation.Degrees0,
                PixelClockRate = 10000000,
                PixelPolarity = false,
                DataEnablePolarity = false,
                DataEnableIsFixed = false,
                HorizontalFrontPorch = 2,
                HorizontalBackPorch = 2,
                HorizontalSyncPulseWidth = 41,
                HorizontalSyncPolarity = false,
                VerticalFrontPorch = 2,
                VerticalBackPorch = 2,
                VerticalSyncPulseWidth = 10,
                VerticalSyncPolarity = false,
            });

            var display = Graphics.FromHdc(controller.Hdc);

            // set font size
            var fontHeight = 16;
            var fontWidth = 16;

            // setup the screen matrix and initial conditions of y
            var height = controller.ActiveConfiguration.Height / fontHeight;
            var width = controller.ActiveConfiguration.Width / fontWidth;

            //Starting y positions of white characters
            var y = new int[width];

            for (int i = 0; i < width; ++i)
            {
                // gets random number between 0 and the height
                y[i] = rand.Next(height);
            }

            // enable screen 
            controller.Enable();
            display.Clear();

            // do the Matrix effect
            // every loop all y's get incremented by 1
            while (true)
            {
                int x;

                for (x = 0; x < width; ++x)
                {
                    // the bright white character
                    display.FillRectangle(new SolidBrush(Color.Black), x * fontWidth, y[x] * fontHeight, fontWidth, fontHeight);
                    display.DrawString(AsciiCharacter.ToString(), digitalFont, new SolidBrush(Color.White), x * fontWidth, y[x] * fontHeight);

                    // the green character - 1 positions above the bright white character
                    int temp = y[x] - 1;
                    display.FillRectangle(new SolidBrush(Color.Black), x * fontWidth, InScreenYPosition(temp, height) * fontHeight, fontWidth, fontHeight);
                    display.DrawString(AsciiCharacter.ToString(), digitalFont, new SolidBrush(Color.Green), x * fontWidth, InScreenYPosition(temp, height) * fontHeight);

                    // the 'blank space' - 10 positions above the green character
                    int temp1 = y[x] - 10;
                    display.FillRectangle(new SolidBrush(Color.Black), x * fontWidth, InScreenYPosition(temp1, height) * fontHeight, fontWidth, fontHeight);

                    // increment y
                    y[x] = InScreenYPosition(y[x] + 1, height);
                }

                display.Flush();
                
                Thread.Sleep(50); // This will run for less then one minute then throw System.NotSupportedException
            }
        }

        // Deals with what happens when y position is off screen
        public static int InScreenYPosition(int yPosition, int height)
        {
            if (yPosition < 0)
                return yPosition + height;
            else if (yPosition < height)
                return yPosition;
            else
                return 0;
        }
    }
}