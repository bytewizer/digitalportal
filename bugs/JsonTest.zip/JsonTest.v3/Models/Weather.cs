﻿namespace Bytewizer.TinyCLR.DigitalPortal.Client.Models
{

#pragma warning disable IDE1006 // Naming Styles

    public class Weather
    {
        public string id { get; set; }
        public string main { get; set; }
        public string description { get; set; }
        public string icon { get; set; }
    }

#pragma warning restore IDE1006 // Naming Styles

}
