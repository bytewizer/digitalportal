﻿namespace Bytewizer.TinyCLR.DigitalPortal.Client.Models
{

#pragma warning disable IDE1006 // Naming Styles

    public class FeelsLike
    {
        public double day { get; set; }
        public double night { get; set; }
        public double eve { get; set; }
        public double morn { get; set; }
    }

#pragma warning restore IDE1006 // Naming Styles

}
